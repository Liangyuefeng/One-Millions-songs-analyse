# utf-8
import re
import time
import tables
from os import listdir
import csv

class Song:
    songCount = 0

    def __init__(self, songID):
        self.id = songID
        Song.songCount += 1
   
        self.track_id = None
        self.analysis_sample_rate = None
        self.artist_familiarity = None
        self.artist_hotness = None
        self.artist_latitude = None
        self.artist_longitude = None
        self.artistLocation = None
        self.artist_name = None

        self.duration = None
        self.key = None
        self.loudness = None
        self.mode = None
        self.album_name = None
        self.song_hotness = None
        self.start_of_fade_out = None
        self.tempo = None
        self.title = None
        self.year = None
        self.end_of_fade_in = None



def open_h5_file_read(h5filename):
    """
    Open an existing H5 in read mode.
    Same function as in hdf5_utils, here so we avoid one import
    """
    return tables.open_file(h5filename, mode='r')


def get_analysis_sample_rate(h5, songidx=0):
    """
    Get analysis sample rate from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.analysis_sample_rate[songidx]


def get_artist_familiarity(h5, songidx=0):
    """
    Get artist familiarity from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.artist_familiarity[songidx]


def get_artist_hotness(h5, songidx=0):
    """
    Get artist hotttnesss from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.artist_hotttnesss[songidx]


def get_artist_latitude(h5, songidx=0):
    """
    Get artist latitude from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.artist_latitude[songidx]


def get_artist_longitude(h5, songidx=0):
    """
    Get artist longitude from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.artist_longitude[songidx]


def get_artist_location(h5, songidx=0):
    """
    Get artist location from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.artist_location[songidx]


def get_artist_name(h5, songidx=0):
    """
    Get artist name from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.artist_name[songidx]


def get_duration(h5, songidx=0):
    """
    Get duration from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.duration[songidx]


def get_key(h5, songidx=0):
    """
    Get key from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.key[songidx]


def get_loudness(h5, songidx=0):
    """
    Get loudness from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.loudness[songidx]


def get_mode(h5, songidx=0):
    """
    Get mode from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.mode[songidx]


def get_release(h5, songidx=0):
    """
    Get release from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.release[songidx]


def get_song_id(h5, songidx=0):
    """
    Get song id from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.song_id[songidx]


def get_song_hotness(h5, songidx=0):
    """
    Get song hotttnesss from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.song_hotttnesss[songidx]


def get_start_of_fade_out(h5, songidx=0):
    """
    Get start of fade out from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.start_of_fade_out[songidx]


def get_title(h5, songidx=0):
    """
    Get title from a HDF5 song file, by default the first song in it
    """
    return h5.root.metadata.songs.cols.title[songidx]


def get_tempo(h5, songidx=0):
    """
    Get tempo from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.tempo[songidx]


def get_year(h5, songidx=0):
    """
    Get release year from a HDF5 song file, by default the first song in it
    """
    return h5.root.musicbrainz.songs.cols.year[songidx]


def get_track_id(h5, songidx=0):
    """
    Get track id from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.track_id[songidx]


def get_end_of_fade_in(h5, songidx=0):
    """
    Get end of fade in from a HDF5 song file, by default the first song in it
    """
    return h5.root.analysis.songs.cols.end_of_fade_in[songidx]


def main():
    print("start")
    outputFile1 = open('NumSongDataset1.csv', 'w')           #open a csv file 

    #################################################
    # change the order of the csv file here
    # Default is to list all available attributes (in alphabetical order)
    csvRowString = ("Track_ID,SongID,AlbumName,Title,ArtistName,ArtistLatitude,ArtistLongitude,ArtistLocation," +
                    'Analysis_sample_rate,ArtistFamiliarity,ArtistHotness,End_of_fade_in,' +
                    "Key,Mode,Popularity,Start_of_fade_out,Duration,Tempo,Loudness,Year")
    #################################################

    csvAttributeList = re.split('\W+', csvRowString)
    for i, v in enumerate(csvAttributeList):
        csvAttributeList[i] = csvAttributeList[i].lower()
    outputFile1.write("SongNumber,")
    outputFile1.write(csvRowString + "\n")
    csvRowString = ""

    #################################################

    # Set the basedir here, the root directory from which the search
    # for files stored in a (hierarchical data structure) will originate
    basedir = "*****************"  # "*" As the default means the current directory which saved the dataset
    
    #################################################
    
    lvl1 = listdir(basedir)
    for subdir in lvl1:
        currentPath = basedir + subdir + "/"
        lvl2 = listdir(currentPath)
        for subdir2 in lvl2:
            currentPath2 = currentPath + subdir2 + "/"
            lvl3 = listdir(currentPath2)
            for subdir3 in lvl3:
                currentPath3 = currentPath2 + subdir3 + "/"
                lvl4 = listdir(currentPath3)
                for files in lvl4:
                    currentPath4 = currentPath3 + files
                    songH5File = open_h5_file_read(currentPath4)        #read the hdf5 file      
					
                    song = Song(str(get_song_id(songH5File)).lstrip('b' + '\' ').rstrip('\' '))           #extract the song_id column and clean it
                    song.track_id = str(get_track_id(songH5File)).lstrip('b' + '\' ').rstrip('\' ').strip('"')
                    song.analysis_sample_rate = str(get_analysis_sample_rate(songH5File))
                    song.artist_familiarity = str(get_artist_familiarity(songH5File))
                    song.artist_hotness = str(get_artist_hotness(songH5File))
                    song.artist_latitude = str(get_artist_latitude(songH5File))
                    song.artist_longitude = str(get_artist_longitude(songH5File))
                    song.artistLocation = str(get_artist_location(songH5File)).lstrip('b' + '\' ').rstrip('\' ')
                    song.artist_name = str(get_artist_name(songH5File)).lstrip('b' + '\' ').rstrip('\' ').strip('"')

                    song.duration = str(get_duration(songH5File))
                    song.key = str(get_key(songH5File))
                    song.loudness = str(abs(get_loudness(songH5File)))
                    song.mode = str(get_mode(songH5File))

                    song.end_of_fade_in = str(get_end_of_fade_in(songH5File))

                    song.albumName = str(get_release(songH5File)).lstrip('b' + '\' ').rstrip("[\s+\.\!\/_,$%^*( "
                                                                                             "+\"\"\']+|["
                                                                                             "+——!,???~@#?%……&*(]+").strip('"')

                    song.song_hotness = str(get_song_hotness(songH5File))
                    song.start_of_fade_out = str(get_start_of_fade_out(songH5File))
                    song.tempo = str(get_tempo(songH5File))
                    song.title = str(get_title(songH5File)).lstrip('b' + '\' ').rstrip("[\s+\.\!\/_,$%^*( "
                                                                                       "+\"\"\']+|["
                                                                                       "+——!,???~@#?%……&*(]+").strip('"')
                    song.year = str(get_year(songH5File))

                    csvRowString = ""
                    csvRowString += str(song.songCount) + ","

                    missing_flag = 0  # turns to 1 if there is any datapoint mising
                    var = r'\xc'       # clean the column with this symbol

                    for attribute in csvAttributeList:
                        if attribute == 'SongID'.lower():
                            csvRowString += song.id
                        elif attribute == 'Track_ID'.lower():
                            csvRowString += song.track_id

                        elif attribute == 'AlbumName'.lower():
                            albumName = song.albumName
                            albumName = albumName.replace('\"', "")
                            albumName = albumName.replace(',', "")
                            csvRowString += "\"" + albumName + "\""
                            if var in albumName:
                                missing_flag = 1

                        elif attribute == 'Title'.lower():
                            Title = song.title
                            Title = Title.replace('\"', "'")
                            csvRowString += "\"" + Title + "\""
                            if Title == "0" or Title == "nan" or var in Title:  # discard missing values
                                missing_flag = 1

                        elif attribute == 'ArtistName'.lower():
                            ArtistName = song.artist_name
                            ArtistName = ArtistName.replace('\"', "'")
                            csvRowString += "\"" + ArtistName + "\""
                            if ArtistName == "0" or ArtistName == "nan" or var in ArtistName:  # discard missing values
                                missing_flag = 1

                        elif attribute == 'ArtistLatitude'.lower():
                            csvRowString += song.artist_latitude
                            if song.artist_latitude == "0" or song.artist_latitude == "nan":  # discard missing values
                                missing_flag = 1

                        elif attribute == 'ArtistLocation'.lower():
                            location = song.artistLocation
                            location = location.replace(',', '')
                            if location == 'b':
                                location = 'nan'

                            for k, v in city_country.items():
                                if location == k:
                                    location = v
                                elif location == v:
                                    location = v
                            if location in statename_list:
                                location = 'USA'
                            # elif location == 'United Kingdom':
                            #     location = 'UK'

                            words = location.split()
                            for value in words:
                                for k, v in city_country.items():
                                    if value == k:
                                        location = v
                                    elif value.title() == v:
                                        location = v
                                if value in statecode_list or value.title() in statename_list:
                                    location = 'USA'
                                elif value == 'Britain' or value == 'Kingdom' or value == 'England' \
                                        or value == 'Scotland' or value == 'Wales':
                                    location = "UK"

                            csvRowString += "\"" + location + "\""
                            words2 = location.split()
                            if len(words2) > 2 or location == "" or var in location:
                                missing_flag = 1

                        elif attribute == 'ArtistLongitude'.lower():
                            csvRowString += song.artist_longitude
                            if song.artist_latitude == "0" or song.artist_latitude == "nan":  # discard missing values
                                missing_flag = 1

                        elif attribute == 'Analysis_sample_rate'.lower():
                            csvRowString += song.analysis_sample_rate
                            if song.analysis_sample_rate == "0.0" or song.analysis_sample_rate == "nan": # discard missing values
                                missing_flag = 1
                        elif attribute == 'ArtistFamiliarity'.lower():
                            csvRowString += song.artist_familiarity
                            if song.artist_familiarity == "0.0" or song.artist_familiarity == "nan": # discard missing values
                                missing_flag = 1
                        elif attribute == 'ArtistHotness'.lower():
                            csvRowString += song.artist_hotness
                            if song.artist_hotness == "0.0" or song.artist_hotness == "nan": # discard missing values
                                missing_flag = 1

                        elif attribute == 'Key'.lower():
                            csvRowString += song.key

                        elif attribute == 'Mode'.lower():
                            csvRowString += song.mode

                        elif attribute == 'Popularity'.lower():
                            csvRowString += song.song_hotness
                            if song.song_hotness == "0.0" or song.song_hotness == "nan":  # discard missing values
                                missing_flag = 1
                        elif attribute == 'Start_of_fade_out'.lower():
                            csvRowString += song.start_of_fade_out

                        elif attribute == 'Duration'.lower():
                            csvRowString += song.duration
                            if song.duration == "0" or song.duration == "nan":  # discard missing values
                                missing_flag = 1

                        elif attribute == 'Tempo'.lower():
                            csvRowString += song.tempo
                            if song.tempo == "0.0" or song.tempo == "nan":  # discard missing values
                                missing_flag = 1

                        elif attribute == 'Loudness'.lower():
                            csvRowString += song.loudness
                            if song.loudness == "0.0" or song.loudness == "nan":  # discard missing values
                                missing_flag = 1

                        elif attribute == 'Year'.lower():
                            csvRowString += song.year
                            if song.year == "0" or song.year == "nan":  # discard missing values
                                missing_flag = 1
                        elif attribute == "End_of_fade_in".lower():
                            csvRowString += song.end_of_fade_in

                        else:
                            csvRowString += "Erm. This didn't work. Error. :( :(\n"

                        csvRowString += ","

                    songH5File.close()  # closed here so that to make sure even the missing files are closed
                    if missing_flag == 1:
                        continue

                    # Remove the final comma from each row in the csv
                    lastIndex = len(csvRowString)
                    csvRowString = csvRowString[0:lastIndex - 1]
                    csvRowString += "\n"

                    # write after excluding datapoints with missing values
                    outputFile1.write(csvRowString)
                    csvRowString = ""

    outputFile1.close()
    print("end")


if __name__ == "__main__":
    start_time = time.time()
	
    statecode_list = ['AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'DC', 'FL', 'GA', 'HI', 'ID', 'IL', 'IN', 'IA',
                      'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM',
                      'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA',
                      'WV', 'WI', 'WY', 'PR']                    # USA statecode for clean the artistlocation column  

    statename_list = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware',
                      'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky',
                      'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi',
                      'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico',
                      'New York', 'North Carolin', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania',
                      'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
                      'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming']    # USA statename for clean the artistlocation column

    csvFile = open("world-cities.csv", "r", encoding="utf8")          # a csv file included most cities name which map to its countries around the world, which used to cleand the artistlocation column 
    reader = csv.reader(csvFile)
    city_country = {}
    for item in reader:
        if reader.line_num == 1:  # Ignore the first line
            continue
        city_country[item[0]] = item[1]
    csvFile.close()

    main()
    print("Total time:", time.time() - start_time, "seconds")
