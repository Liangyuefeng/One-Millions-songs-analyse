
from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import *
import pyspark.sql.functions as f
from pyspark.sql import SparkSession


spark = SparkSession.builder.appName('MSD').getOrCreate()

file = "hdfs:/user/yxl13-kkr16/NumSongDataset1.csv"   # csv file path

df = spark.read.format("csv").options(delimiter=',') \
    .options(header=True) \
    .options(inferSchema=True) \
    .load(file)

#df.write.parquet('input-parquet')

file = df.write.format("parquet").save("hdfs:/user/yxl13-kkr16/CleanedSongDataset1.parquet")


df = spark.read.format("parquet").options(inferSchema=True).load("hdfs:/user/yxl13-kkr16/CleanedSongDataset1.parquet")
df.show()