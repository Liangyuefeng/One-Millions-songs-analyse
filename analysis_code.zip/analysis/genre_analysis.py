import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from pyspark.sql import SparkSession
from collections import Counter

spark = SparkSession.builder.appName('MSDG').getOrCreate()

df = spark.read.format("parquet").options(inferSchema=True).load("GENER43.parquet")
# df.show()
print("-----------------")

type_list = []
size_type = df.select(df.GENER_TYPE).dropDuplicates().count()
for i in range(0, 15):
    location2 = df.select(df.GENER_TYPE).dropDuplicates().collect()[i][0]
    type_list.append(location2)
print(type_list)
print('-----------------------------------')
num = []
for i in range(0, len(type_list)):
    val = df.filter(df.GENER_TYPE == type_list[i]).count()
    num.append(val)

print(num)
print('-----------------------------------')
d = dict(zip(type_list, num))

print(d)

fig, ax = plt.subplots()
ax.barh(type_list, num, color='green')
ax.grid(ls='--')
ax.title.set_text(r'The number of songs in different types over the past 20 years')
ax.set_xlabel("Num")
ax.set_ylabel("Music_Type")
plt.xticks([0, 25, 50, 75, 100, 125, 150, 175, 200, 225, 250])


print('-----------------------------------')

df1 = df.select('GENER_TYPE', 'POPULARITY', 'YEAR').filter(df.YEAR > 1990)
sum = df.select('GENER_TYPE').count()
print(sum)


---------------------------------------------------------------------------

def analysis(target):
    df2 = df1.select("POPULARITY", 'YEAR').filter(df.GENER_TYPE == target)
    print('---------------------')

    size = df2.select(df2.YEAR).count()  # number of songs created in the past 10 years
    years = []
    for i in range(0, size):
        year = df2.select("YEAR").collect()[i][0]
        years.append(year)
    print(len(years))

    unique_years = set(years)
    unique_years = list(unique_years)
    unique_years.sort()

    # print(df.filter(df.Year > 2000).count())
    print("---------------------------------------")

    def meananalysis(one_years):
        listtarget = []

        for i in range(0, len(one_years)):
            oneyeartarget = df2.select("POPULARITY").filter(df.YEAR == one_years[i])
            # print("For year:", unique_years[i])
            listtarget.append([one_years[i]])
            sum = 0
            for j in range(0, oneyeartarget.count()):
                field_value = oneyeartarget.collect()[j][0]
                sum += field_value
                # print(year_tempos)
            mean = sum / oneyeartarget.count()
            listtarget[i].append(mean)

        listtarget = dict(listtarget)
        print(listtarget)
        return listtarget

    a = meananalysis(unique_years)
    return a


rock_popularity = analysis("Rock")
pop_popularity = analysis("Pop")
electronic_popularity = analysis("Electronic")
rap_popularity = analysis("Rap")
rnb_popularity = analysis("RnB")

fig1 = plt.figure().add_subplot(111)
fig1.plot(rock_popularity.keys(), rock_popularity.values(), label='Rock_music')
fig1.plot(pop_popularity.keys(), pop_popularity.values(), label='Pop_music')
fig1.plot(electronic_popularity.keys(), electronic_popularity.values(), label='Electronic_music')
fig1.plot(rap_popularity.keys(), rap_popularity.values(), label='Rap_music')
fig1.plot(rnb_popularity.keys(), rnb_popularity.values(), label='Rnb_music')
fig1.title.set_text(r'General trend of 5 different types of songs popularity over the past 20 years')
fig1.set_xlabel('Years')
fig1.set_ylabel('Average Popularity')
fig1.set_ylim(0.2, 1)
fig1.set_xlim(1990, 2010)
fig1.grid(ls='--')
fig1.set_xticks(np.arange(1990, 2012, 2))
plt.legend()



# ------------------------------------------------------------
df1 = df.select('GENER_TYPE', 'POPULARITY').filter(df['YEAR'] > 1990)
df2 = df1.select('GENER_TYPE').filter(df.POPULARITY >= 0.8)

size20 = df2.select('GENER_TYPE').count()  # number of songs created in the past 20 years
location20_num = []
for i in range(0, size20):
    location1 = df2.select("GENER_TYPE").collect()[i][0]
    location20_num.append(location1)

result20 = Counter(location20_num)
e = dict(result20)
print(e)

type_popular = []
num = []
for k, v in e.items():
    type_popular.append(k)
    num.append(v)

num_percen = []
for i in range(0, len(num)):
    for k, v in d.items():
        if type_popular[i] == k:
            a = (num[i]/v)*10
            num_percen.append(a)

print(num_percen)
fig2 = plt.figure().add_subplot(111)
fig2.barh(type_popular, num_percen, color='green')
fig2.grid(ls='--')
fig2.title.set_text(r'The number of popular songs in different types over the past 20 years')
fig2.set_xlabel("Num")
fig2.set_ylabel("Music_Type")


def to_percent(temp, position):
    return '%1.0f' % (10*temp) + '%'

plt.gca().xaxis.set_major_formatter(FuncFormatter(to_percent))


plt.show()
