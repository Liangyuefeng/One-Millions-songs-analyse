from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

conf = SparkConf().setAppName('MillionSongsAnalysis')
sc = SparkContext(conf=conf)

spark = SparkSession.builder.appName('MillionSongsAnalysis').getOrCreate()

file = 'NumSongDataset.parquet'
df = spark.read.format("parquet").options(inferSchema=True).load(file)

years = []                         # make some list, we need to use these list to calculate the correction matrix
popularities = []
artisthotness = []
artistfamiliarities = []
tempos = []
durations = []
loudnesses = []
ArtistLatitude = []
ArtistLongitude = []
End_of_fade_in = []
keys = []
modes = []

size = df.select('Year').count()
for i in range(0, size):
    year = df.select("Year").collect()[i][0]
    popularity = df.select("Popularity").collect()[i][0]
    artisthottest = df.select("ArtistHotness").collect()[i][0]
    artistfamiliarity = df.select("ArtistFamiliarity").collect()[i][0]
    tempo = df.select("Tempo").collect()[i][0]
    loudness = df.select("Loudness").collect()[i][0]
    duration = df.select("Duration").collect()[i][0]
    latitude = df.select("ArtistLatitude").collect()[i][0]
    longitude = df.select("ArtistLongitude").collect()[i][0]
    fade_in = df.select("End_of_fade_in").collect()[i][0]
    key = df.select("Key").collect()[i][0]
    mode = df.select("Mode").collect()[i][0]
    years.append(year)
    popularities.append(popularity)
    artisthotness.append(artisthottest)
    artistfamiliarities.append(artistfamiliarity)
    tempos.append(tempo)
    loudnesses.append(loudness)
    durations.append(duration)
    ArtistLatitude.append(latitude)
    ArtistLongitude.append(longitude)
    End_of_fade_in.append(fade_in)
    keys.append(key)
    modes.append(mode)
print(len(modes))
print(len(years))
print(len(keys))
print("---------------------------------------")


def CorrelationMartix(popularities, artisthotness, artistfamiliarities, tempos, loudnesses, durations, years ,
                      ArtistLatitude, ArtistLongitude, End_of_fade_in, keys, modes):
    Alllist = [popularities, artisthotness, artistfamiliarities, tempos, loudnesses, durations, years, ArtistLatitude,
               ArtistLongitude, End_of_fade_in, keys, modes]

    column_lst = ['popularity', 'artisthotness', 'artistfamiliarity', 'tempo', 'loudness', 'duration', 'year',
                  'ArtistLatitude', 'ArtistLongitude', 'End_of_fade_in', 'keys', 'modes']

    data_dict = {}            # use a dictionary
    for col, gf_lst in zip(column_lst, Alllist):
        data_dict[col] = gf_lst

    unstrtf_df = pd.DataFrame(data_dict)
    cor1 = unstrtf_df.corr()  # use pandas corr calculate the correction
    print(cor1)
    return cor1


cor = CorrelationMartix(popularities, artisthotness, artistfamiliarities, tempos, loudnesses, durations, years,
                        ArtistLatitude, ArtistLongitude, End_of_fade_in, keys, modes)
fig = plt.figure()
ax = fig.add_subplot(figsize=(110, 110))
ax = sns.heatmap(cor, annot=True, vmax=1, square=True, cmap="RdBu_r")
ax.set_title('characteristic_correlation')
plt.show()


