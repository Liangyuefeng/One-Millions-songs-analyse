from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


conf = SparkConf().setAppName('MillionSongsAnalysis')
sc = SparkContext(conf=conf)

spark = SparkSession.builder.appName('MillionSongsAnalysis').getOrCreate()


file = 'NumSongDataset.parquet'
df = spark.read.format("parquet").options(inferSchema=True).load(file)


size10 = df.filter(df.Year > 1990).count()  # number of songs created in the past 20 years
years = []
for i in range(0, size10):
    year = df.select("Year").filter(df.Year > 1990).collect()[i][0]
    years.append(year)
print(len(years))

unique_years = set(years)
unique_years = list(unique_years)
unique_years.sort()

print("---------------------------------------")


def analysis(one_years, target):
    listtarget = []

    for i in range(0, len(one_years)):
        oneyeartarget = df.select(target).filter(df.Year == one_years[i])
        listtarget.append([one_years[i]])
        a = []
        for j in range(0, oneyeartarget.count()):
            field_value = oneyeartarget.collect()[j][0]
            a.append(field_value)
            
        listtarget[i].append(a)

    listtarget = dict(listtarget)
    return listtarget


loudness = analysis(unique_years, "Loudness")
artisthotness = analysis(unique_years, "ArtistHotness")
artistfamiliarity = analysis(unique_years,'ArtistFamiliarity')
popularity = analysis(unique_years, "Popularity")

avg = []
Var = []
SD = []
data = []
year = []
for keys, values in popularity.items():   # loudness, artisthotness, artistfamiliarity,popularity, general trend analysis of these four features over 20 years 
    avg.append(np.average(values))
    Var.append(np.var(values))
    SD.append(np.std(values, ddof=1))
    data.append(values)
    year.append(keys)

# for keys, values in loudness.items():   # Remove the comment when you pick up which feature you want to analysis
    # avg.append(np.average(values))
    # Var.append(np.var(values))
    # SD.append(np.std(values, ddof=1))
    # data.append(values)
    # year.append(keys)	

# for keys, values in artisthotness.items():   
    # avg.append(np.average(values))
    # Var.append(np.var(values))
    # SD.append(np.std(values, ddof=1))
    # data.append(values)
    # year.append(keys)

# for keys, values in artistfamiliarity.items():   
    # avg.append(np.average(values))
    # Var.append(np.var(values))
    # SD.append(np.std(values, ddof=1))
    # data.append(values)
    # year.append(keys)	

print(avg)
print(Var)
print(SD)
print(year)
print("---------------------------------------")

fig1 = plt.figure().add_subplot(111)

fig1.plot(year, SD, 'b', linewidth=1)
fig1.errorbar(year, avg, SD, capsize=5, elinewidth=1, markeredgewidth=2, ecolor='red', fmt='r', linewidth=1,
              capthick=0.5)
red_patch = mpatches.Patch(color='red', label='means+SD')
blue_patch = mpatches.Patch(color='blue', label='Standard_deviation')
fig1.legend(handles=[red_patch, blue_patch])
fig1.set_xlabel("Year")
fig1.set_xticks(np.arange(1990, 2012, 2))
fig1.set_ylabel("Popularity")

fig1.title.set_text("Average + SD of Song Popularity over the past 20 years")
fig1.grid(True)



plt.show()


