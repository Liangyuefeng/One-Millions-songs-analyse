from pyspark.ml import Pipeline
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.feature import IndexToString, StringIndexer, VectorIndexer, VectorAssembler
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.ml.feature import StringIndexer
from pyspark.ml.feature import OneHotEncoder
import numpy as np
import warnings
warnings.filterwarnings("ignore")
'''
https://creativedata.atlassian.net/wiki/spaces/SAP/pages/83237142/Pyspark+-+Tutorial+based+on+Titanic+Dataset
'''

# Load and parse the data file, converting it to a DataFrame.
spark = SparkSession.builder.appName('MillionSongsAnalysis').getOrCreate()
file = 'M:/Big D group project/Code/CleanedSongDataset.parquet'
df = spark.read.format("parquet").options(inferSchema=True).load(file)
df.cache()

target = "Year"
#Get numeric columns besides target
numeric_cols_names = [] # holds the names of all the numeric columns
categorical_cols_names = [] #holds the names of all the categorical columns
for c in df.columns:
    #print(df.schema[c].dataType)
    if(c!=target and (isinstance(df.schema[c].dataType, LongType) or isinstance(df.schema[c].dataType, DoubleType) or isinstance(df.schema[c].dataType, FloatType) or isinstance(df.schema[c].dataType, IntegerType))): #https://stackoverflow.com/questions/48450352/pyspark-how-to-judge-column-type-of-dataframe
        numeric_cols_names.append(c)
    elif(c!=target and c=="ArtistLocation" ):
        categorical_cols_names.append(c)
print(numeric_cols_names)
print(categorical_cols_names)

RUNS = 100
test_error_all = []
accuracy_all = []
f1_all = []
wp_all = []
wr_all = []
for r in range(0,RUNS):
    # Spliting in train and test set. Beware : It sorts the dataset
    (traindf, testdf) = df.randomSplit([0.1,0.9])

    labelIndexer = StringIndexer(inputCol=target, outputCol="label").fit(df)
    #df.printSchema()
    
    # One Hot Encoder on indexed features
    #embarkEncoder = OneHotEncoder(inputCol="indexedEmbarked", outputCol="embarkedVec")
    
    # Create the vector structured data (label,features(vector))
    assembler = VectorAssembler(inputCols= numeric_cols_names ,outputCol="features")

    # Train a RandomForest model.
    rf = RandomForestClassifier(labelCol= "label", featuresCol="features")

    # Convert indexed labels back to original labels.
    labelConverter = IndexToString(inputCol="prediction", outputCol="predictedLabel", labels=labelIndexer.labels)

    # Chain indexers and forest in a Pipeline  
    pipeline = Pipeline(stages = [labelIndexer, assembler, rf, labelConverter]) # genderIndexer,embarkIndexer,genderEncoder,embarkEncoder,
    
    # Train model.  This also runs the indexers.
    model = pipeline.fit(traindf)
    
    # Predictions
    predictions = model.transform(testdf)
    
    # Select example rows to display.
    predictions.columns 
    
    # Select example rows to display.
    predictions.select("predictedLabel", target, "features").show(10)
    
    # Select (prediction, true label) and compute test error
    predictions = predictions.select(col(target).cast("Int"),col("prediction"))
    evaluator = MulticlassClassificationEvaluator(labelCol= target, predictionCol="prediction", metricName="accuracy")
    accuracy = evaluator.evaluate(predictions)
    test_error_all.append(1.0 - accuracy)
    print("Test Error = %g" % (1.0 - accuracy))

    
    rfModel = model.stages[0]
    print(rfModel)  # summary only
    
    evaluator = MulticlassClassificationEvaluator(labelCol= target, predictionCol="prediction", metricName="accuracy")
    accuracy = evaluator.evaluate(predictions)
    accuracy_all.append(accuracy)
    print("Accuracy = %g" % accuracy)
    
    evaluatorf1 = MulticlassClassificationEvaluator(labelCol= target, predictionCol="prediction", metricName="f1")
    f1 = evaluatorf1.evaluate(predictions)
    f1_all.append(f1)
    print("f1 = %g" % f1)
    
    evaluatorwp = MulticlassClassificationEvaluator(labelCol= target, predictionCol="prediction", metricName="weightedPrecision")
    wp = evaluatorwp.evaluate(predictions)
    wp_all.append(wp)
    print("weightedPrecision = %g" % wp)
    
    evaluatorwr = MulticlassClassificationEvaluator(labelCol= target, predictionCol="prediction", metricName="weightedRecall")
    wr = evaluatorwr.evaluate(predictions)
    wr_all.append(wr)
    print("weightedRecall = %g" % wr)

avg_test_error = np.sum(test_error_all) / len(test_error_all)
print("Average Test Error:", avg_test_error) 
avg_accuracy = np.sum(accuracy_all) / len(accuracy_all)
print("Average Accuracy:", avg_accuracy) 
avg_wp = np.sum(wp_all) / len(wp_all)
print("Average weightedPrecision:", avg_wp) 
avg_wr = np.sum(wr_all) / len(wr_all)
print("Average weightedRecall:", avg_wr) 
 
# close sparkcontext
#sc.stop()


