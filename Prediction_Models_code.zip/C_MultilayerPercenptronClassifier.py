from pyspark.ml.classification import LinearSVC
from pyspark.ml import Pipeline
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import IndexToString, StringIndexer, VectorIndexer, VectorAssembler
from pyspark.sql.types import *
import numpy as np
from pyspark.ml.classification import MultilayerPerceptronClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.feature import StringIndexer
from pyspark.ml.feature import OneHotEncoder
import math
import warnings
warnings.filterwarnings("ignore")
'''
Reference:

https://spark.apache.org/docs/latest/ml-classification-regression.html#random-forests
'''

def year_bucketing(year_number):
    if year_number < 1950:
        return '1950'
    elif year_number < 1970:
        return '1970'
    elif year_number < 1990:
        return '1990'
    elif year_number < 2000:
        return '2000'
    return '2012'

# Load and parse the data file, converting it to a DataFrame.
spark = SparkSession.builder.appName('MillionSongsAnalysis').getOrCreate()
file = 'M:/Big D group project/Code/CleanedSongDataset.parquet'
df = spark.read.format("parquet").options(inferSchema=True).load(file)
df.cache() #@@@check persist   persist allows more customization on how/where to temp. save the loaded data

#bucketing year values for classifier
udf_year_bucket = udf(year_bucketing, StringType())
df = df.withColumn("Year_bucketed", udf_year_bucket("Year"))
df.groupBy("Year_bucketed").count().show()

target = "Year"
#Get numeric columns besides target
numeric_cols_names = [] # holds the names of all the numeric columns
categorical_cols_names = [] #holds the names of all the categorical columns
for c in df.columns:
    #print(df.schema[c].dataType)
    if(c!=target and (isinstance(df.schema[c].dataType, LongType) or isinstance(df.schema[c].dataType, DoubleType) or isinstance(df.schema[c].dataType, FloatType) or isinstance(df.schema[c].dataType, IntegerType))): #https://stackoverflow.com/questions/48450352/pyspark-how-to-judge-column-type-of-dataframe
        numeric_cols_names.append(c)
    elif(c!=target and c=="ArtistLocation" ):
        categorical_cols_names.append(c)
print(numeric_cols_names)
print(categorical_cols_names)

#Encode the categorical variables (dummy encoding)
latest_encoded_df = df
for c in categorical_cols_names:
    indexed_df = StringIndexer(inputCol= c, outputCol="indexed_" + c).fit(latest_encoded_df).transform(latest_encoded_df)

    encoder = OneHotEncoder(inputCol="indexed_" + c, outputCol="vectorOf_" + c)
    encoded_df = encoder.transform(indexed_df)

    #numeric_cols_names.append("vectorOf_" + c)
    latest_encoded_df = encoded_df

# Split the data into train and test
splits = latest_encoded_df.randomSplit([0.7, 0.3], 1234)
train = splits[0]
test = splits[1]


labelIndexer = StringIndexer(inputCol=target, outputCol="label").fit(latest_encoded_df)  


# Create the vector structured data (label,features(vector))
assembler = VectorAssembler(inputCols= numeric_cols_names ,outputCol="features")


# specify layers for the neural network:
# input layer of size 4 (features), two intermediate of size 5 and 4                          -->ex  [4, 5, 5, 3]
# and output of size 3 (classes) 
num_features = len(numeric_cols_names)
num_classes = latest_encoded_df.select(target).distinct().count() #number of unique classes (values) of the target Feature

hidlayer1 = 10
hidlayer2 = 5
increment = 10
best_accuracy = 0
best_hidlayer1 = 0
best_hidlayer2 = 0
RUNS = 100
for iter1 in range(0, int(math.sqrt(RUNS))):
    hidlayer1 = iter1 * increment + 10


    for iter2 in range(0, int(math.sqrt(RUNS))): 
        hidlayer2 = iter2 * increment + 5
        print("layer1:", hidlayer1, "layer2:", hidlayer2)
        layers = [num_features, hidlayer1, hidlayer2, num_classes]

        # create the trainer and set its parameters
        mpc = MultilayerPerceptronClassifier(maxIter=100, layers=layers, blockSize=128, seed=1234)

        # Convert indexed labels back to original labels.
        labelConverter = IndexToString(inputCol="prediction", outputCol="predictedLabel", labels=labelIndexer.labels)

        # Chain indexers and forest in a Pipeline  
        pipeline = Pipeline(stages = [labelIndexer, assembler, mpc, labelConverter]) # genderIndexer,embarkIndexer,genderEncoder,embarkEncoder,


        # train the model
        model = pipeline.fit(train)

        # compute accuracy on the test set
        predictions = model.transform(test)
        predictionAndLabels = predictions.select("prediction", "label")
        evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
        accuracy = evaluator.evaluate(predictionAndLabels)
        print("Test set accuracy = " + str(accuracy))
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_hidlayer1 = hidlayer1
            best_hidlayer2 = hidlayer2
print("Best accuracy was:", best_accuracy, "for hidden layer values:", best_hidlayer1, "", hidlayer2)            



#https://mapr.com/blog/churn-prediction-pyspark-using-mllib-and-ml-packages/