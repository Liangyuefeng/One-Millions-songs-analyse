from pyspark.ml.regression import LinearRegression
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import StandardScaler
from pyspark.ml import Pipeline
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.feature import StringIndexer
from pyspark.ml.feature import OneHotEncoder
import numpy as np

import warnings
warnings.filterwarnings("ignore")

'''
Code based on:
http://spark.apache.org/docs/2.0.0/api/python/_modules/pyspark/ml/evaluation.html
https://blog.epigno.systems/2018/02/18/machine-learning-with-pyspark-linear-regression/
'''
spark = SparkSession.builder.appName('MillionSongsAnalysis').getOrCreate()

file = 'M:/Big D group project/Code/CleanedSongDataset.parquet'
df = spark.read.format("parquet").options(inferSchema=True).load(file)
df.cache()
#df.printSchema()

target = "Year"
#Get numeric columns besides target
numeric_cols_names = [] # holds the names of all the numeric columns
categorical_cols_names = [] #holds the names of all the categorical columns
for c in df.columns:
    #print(df.schema[c].dataType)
    if(c!=target and (isinstance(df.schema[c].dataType, LongType) or isinstance(df.schema[c].dataType, DoubleType) or isinstance(df.schema[c].dataType, FloatType) or isinstance(df.schema[c].dataType, IntegerType))): #https://stackoverflow.com/questions/48450352/pyspark-how-to-judge-column-type-of-dataframe
        numeric_cols_names.append(c)
    elif(c!=target and c=="ArtistLocation"):
        categorical_cols_names.append(c)
print(numeric_cols_names)
print(categorical_cols_names)

#Rename target column so that it matches the algorithm "tag"
r_df = df.withColumnRenamed(target, "label") #dataFrame for regression with the column name change

#Encode the categorical variables (dummy encoding)
latest_encoded_df = r_df
for c in categorical_cols_names:
    indexed_df = StringIndexer(inputCol= c, outputCol="indexed_" + c).fit(latest_encoded_df).transform(latest_encoded_df)

    encoder = OneHotEncoder(inputCol="indexed_" + c, outputCol="vectorOf_" + c)
    encoded_df = encoder.transform(indexed_df)

    numeric_cols_names.append("vectorOf_" + c)
    latest_encoded_df = encoded_df

RUNS = 100
rmse_all = []
mse_all = []
mae_all = []
r2_all = [] # determination coefficients 
for i in range(0, RUNS):
    (training, test) = latest_encoded_df.randomSplit([0.70, 0.30])

    vectorAssembler = VectorAssembler(inputCols=numeric_cols_names, outputCol="features")
    #standardScaler = StandardScaler(inputCol="unscaled_features", outputCol="features")
    lr = LinearRegression(maxIter=10, regParam=.01)

    stages = [vectorAssembler, lr]
    pipeline = Pipeline(stages=stages)

    #Fit the training data and transform the test data
    model = pipeline.fit(training)
    prediction = model.transform(test)

    #prediction.show()

    #EVALUATION OF THE MODEL
    eval = RegressionEvaluator(labelCol="label", predictionCol="prediction", metricName="rmse")

    # Root Mean Square Error
    rmse = eval.evaluate(prediction)
    print("RMSE: %.6f" % rmse)
    rmse_all.append(rmse)

    # Mean Square Error
    mse = eval.evaluate(prediction, {eval.metricName: "mse"})
    print("MSE: %.6f" % mse)
    mse_all.append(mse)

    # Mean Absolute Error
    mae = eval.evaluate(prediction, {eval.metricName: "mae"})
    print("MAE: %.6f" % mae)
    mae_all.append(mae)

    # r2 - coefficient of determination
    r2 = eval.evaluate(prediction, {eval.metricName: "r2"})
    print("r2: %.6f\n" %r2)
    r2_all.append(r2)

avg_rmse = np.sum(rmse_all) / len(rmse_all)
print("Average RMSE (root mean sqaure error):", avg_rmse)    

avg_mse = np.sum(mse_all) / len(mse_all)
print("Average MSE (mean square error):", avg_mse)

avg_mae = np.sum(mae_all) / len(mae_all)
print("Average MAE (mean absolute error):", avg_mae)

avg_r2 = np.sum(r2_all) / len(r2_all)
print("Average R2 (coefficient of determination):", avg_r2)


