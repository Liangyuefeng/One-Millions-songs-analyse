from pyspark.ml import Pipeline
from pyspark.ml.regression import RandomForestRegressor, LinearRegression
from pyspark.ml.feature import IndexToString, StringIndexer, VectorIndexer, VectorAssembler
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.ml.feature import StringIndexer
from pyspark.ml.feature import OneHotEncoder
import numpy as np
import warnings
warnings.filterwarnings("ignore")

'''
Code based on

https://creativedata.atlassian.net/wiki/spaces/SAP/pages/83237142/Pyspark+-+Tutorial+based+on+Titanic+Dataset

https://blog.epigno.systems/2018/02/18/machine-learning-with-pyspark-linear-regression/ good explanation on how algo works
'''

# Load and parse the data file, converting it to a DataFrame.
spark = SparkSession.builder.appName('MillionSongsAnalysis').getOrCreate()
file = 'M:/Big D group project/Code/CleanedSongDataset.parquet'
df = spark.read.format("parquet").options(inferSchema=True).load(file)
df.cache()

target = "Year"
#Get numeric columns besides target
numeric_cols_names = [] # holds the names of all the numeric columns
categorical_cols_names = [] #holds the names of all the categorical columns
for c in df.columns:
    #print(df.schema[c].dataType)
    if(c!=target and (isinstance(df.schema[c].dataType, LongType) or isinstance(df.schema[c].dataType, DoubleType) or isinstance(df.schema[c].dataType, FloatType) or isinstance(df.schema[c].dataType, IntegerType))): #https://stackoverflow.com/questions/48450352/pyspark-how-to-judge-column-type-of-dataframe
        numeric_cols_names.append(c)
    elif(c!=target and c=="ArtistLocation" ):
        categorical_cols_names.append(c)
numeric_cols_names = ["ArtistFamiliarity", "ArtistHotness", "Loudness"]
print(numeric_cols_names)
print(categorical_cols_names)

#Rename target column so that it matches the algorithm "tag"
r_df = df.withColumnRenamed(target, "label") #dataFrame for regression with the column name change

#Encode the categorical variables (dummy encoding)
latest_encoded_df = r_df
for c in categorical_cols_names:
    indexed_df = StringIndexer(inputCol= c, outputCol="indexed_" + c).fit(latest_encoded_df).transform(latest_encoded_df)

    encoder = OneHotEncoder(inputCol="indexed_" + c, outputCol="vectorOf_" + c)
    encoded_df = encoder.transform(indexed_df)

    #numeric_cols_names.append("vectorOf_" + c)
    latest_encoded_df = encoded_df

latest_encoded_df.printSchema()
RUNS = 100
rmse_all = []
mse_all = []
mae_all = []
r2_all = []
feature_importances = [0] * len(numeric_cols_names)
for r in range(0,RUNS):
    # Spliting in train and test set. Beware : It sorts the dataset
    (traindf, testdf) = latest_encoded_df.randomSplit([0.7,0.3])

    #df.printSchema()
 
    # Create the vector structured data (label,features(vector))
    assembler = VectorAssembler(inputCols= numeric_cols_names ,outputCol="features")

    # Train a RandomForest model.
    rf = RandomForestRegressor(featuresCol="features")
    #rf = LinearRegression(maxIter = 10, regParam = 0.1)

    # Chain indexers and forest in a Pipeline  
    pipeline = Pipeline(stages = [assembler, rf]) # genderIndexer,embarkIndexer,genderEncoder,embarkEncoder,
    
    # Train model.  This also runs the indexers.
    model = pipeline.fit(traindf)
    
    # Predictions
    predictions = model.transform(testdf)
    
    # Select example rows to display.
    predictions.select("prediction", "label", "features").show(10) 
    
    evaluator = RegressionEvaluator(labelCol= "label", predictionCol="prediction", metricName="rmse")
    rmse = evaluator.evaluate(predictions)
    rmse_all.append(rmse)
    print("RMSE = %g" % rmse)

    evaluator = RegressionEvaluator(labelCol= "label", predictionCol="prediction", metricName="mse")
    mse = evaluator.evaluate(predictions)
    mse_all.append(mse)
    print("MSE = %g" % mse)

    evaluator = RegressionEvaluator(labelCol= "label", predictionCol="prediction", metricName="mae")
    mae = evaluator.evaluate(predictions)
    mae_all.append(mae)
    print("MAE = %g" % mae)

    evaluator = RegressionEvaluator(labelCol= "label", predictionCol="prediction", metricName="r2")
    r2 = evaluator.evaluate(predictions)
    r2_all.append(r2)
    print("R2 = %g" % r2)

    print(model.stages[-1].featureImportances)
    #save feature importances
    output = model.stages[-1].featureImportances
    #print(model.stages[-1])
    print(len(numeric_cols_names))
    print(len(output))
    for i in range(len(output)):
        feature_importances[i] += output[i]


avg_rmse = np.sum(rmse_all) / len(rmse_all)
print("Average RMSE:", avg_rmse) 

avg_mse = np.sum(mse_all) / len(mse_all)
print("Average MSE:", avg_mse) 

avg_mae = np.sum(mae_all) / len(mae_all)
print("Average MAE:", avg_mae) 

avg_r2 = np.sum(r2_all) / len(r2_all)
print("Average R2:", avg_r2) 

avg_feature_importances = [x / RUNS for x in feature_importances]

index_featureImportance_dic = {}
#sort dictonary by value
for i in range(0, len(avg_feature_importances)):
    index_featureImportance_dic[i] = avg_feature_importances[i]
sorted_dic = sorted(index_featureImportance_dic.items(), key=lambda kv: kv[1], reverse=True) #list

#create dictionary with the names of features and their importance (ranked by performance)
featureName_featureImportance_dic = {}
for i in range (0, len(sorted_dic)):
    feature = numeric_cols_names[sorted_dic[i][0]] #get feature name with that index
    featureName_featureImportance_dic[feature] =  sorted_dic[i][1]
print(featureName_featureImportance_dic)





